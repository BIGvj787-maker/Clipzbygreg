import os
from dataclasses import dataclass
from pathlib import Path

@dataclass
class Settings:
    telegram_token: str = os.getenv("TELEGRAM_BOT_TOKEN", "")
    telegram_chat_id: str = os.getenv("TELEGRAM_CHAT_ID", "")
    openai_api_key: str = os.getenv("OPENAI_API_KEY", "")
    openai_model: str = os.getenv("OPENAI_MODEL", "gpt-5")
    google_service_account_json: str = os.getenv("GOOGLE_SERVICE_ACCOUNT_JSON", "")
    google_drive_root_folder_id: str = os.getenv("GOOGLE_DRIVE_ROOT_FOLDER_ID", "")
    make_webhook_url: str = os.getenv("MAKE_WEBHOOK_URL", "")
    make_webhook_secret: str = os.getenv("MAKE_WEBHOOK_SECRET", "")
    database_url: str = os.getenv("DATABASE_URL", "sqlite:///./tiktok_bot.db")
    media_dir: str = os.getenv("MEDIA_DIR", "./media")
    poll_seconds: int = int(os.getenv("LIVE_POLL_SECONDS", "30"))
    default_clips: int = int(os.getenv("DEFAULT_CLIPS", "5"))
    max_clip_seconds: int = int(os.getenv("MAX_CLIP_SECONDS", "90"))

settings = Settings()
Path(settings.media_dir).mkdir(parents=True, exist_ok=True)
