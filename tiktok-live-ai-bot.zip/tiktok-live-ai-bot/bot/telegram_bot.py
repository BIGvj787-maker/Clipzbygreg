from telegram.ext import Application,CommandHandler
from config import settings
from bot.commands import start,help_cmd,add,remove,list_cmd,status,recordings,moments,setclips,settings_cmd

def build_bot():
    app=Application.builder().token(settings.telegram_token).build()
    for name,fn in [("start",start),("help",help_cmd),("add",add),("remove",remove),("list",list_cmd),("status",status),("recordings",recordings),("moments",moments),("setclips",setclips),("settings",settings_cmd)]:
        app.add_handler(CommandHandler(name,fn))
    return app
