from telegram import Update
from telegram.ext import ContextTypes
from database.database import SessionLocal, Creator, Session, Moment, Setting
from config import settings

def norm(x): return x if x.startswith("@") else "@"+x

async def start(update:Update,context:ContextTypes.DEFAULT_TYPE): await update.message.reply_text("TikTok LIVE AI clipping bot is running. Use /help.")
async def help_cmd(update,context): await update.message.reply_text("/start /help /add @user /remove @user /list /status /recordings @user /moments @user /clip @user [N] /reanalyze @user /setclips N /stop @user /settings")
async def add(update,context):
    if not context.args: return await update.message.reply_text("Usage: /add @username")
    u=norm(context.args[0].lower())
    with SessionLocal() as db:
        if db.query(Creator).filter_by(username=u).first(): return await update.message.reply_text("Already monitored.")
        db.add(Creator(username=u)); db.commit()
    await update.message.reply_text(f"Monitoring {u}.")
async def remove(update,context):
    if not context.args: return await update.message.reply_text("Usage: /remove @username")
    u=norm(context.args[0].lower())
    with SessionLocal() as db:
        c=db.query(Creator).filter_by(username=u).first()
        if not c:return await update.message.reply_text("Unknown creator.")
        c.enabled=False; db.commit()
    await update.message.reply_text(f"Removed {u}.")
async def list_cmd(update,context):
    with SessionLocal() as db: xs=db.query(Creator).filter_by(enabled=True).all()
    await update.message.reply_text("Monitored:\n"+("\n".join(x.username for x in xs) or "None"))
async def status(update,context):
    with SessionLocal() as db:
        cs=db.query(Creator).filter_by(enabled=True).count(); active=db.query(Session).filter_by(status="recording").count()
        recent=db.query(Session).order_by(Session.id.desc()).limit(5).all()
    await update.message.reply_text(f"Monitored: {cs}\nActive recordings: {active}\nRecent: "+", ".join(x.session_id+":"+x.status for x in recent))
async def recordings(update,context):
    if not context.args:return await update.message.reply_text("Usage: /recordings @username")
    u=norm(context.args[0].lower())
    with SessionLocal() as db:
        c=db.query(Creator).filter_by(username=u).first()
        if not c:return await update.message.reply_text("Unknown creator.")
        xs=db.query(Session).filter_by(creator_id=c.id).order_by(Session.id.desc()).limit(10).all()
    await update.message.reply_text("\n".join(f"{x.session_id} — {x.status}" for x in xs) or "No recordings.")
async def moments(update,context):
    if not context.args:return await update.message.reply_text("Usage: /moments @username")
    u=norm(context.args[0].lower())
    with SessionLocal() as db:
        c=db.query(Creator).filter_by(username=u).first()
        if not c:return await update.message.reply_text("Unknown creator.")
        s=db.query(Session).filter_by(creator_id=c.id).order_by(Session.id.desc()).first()
        ms=db.query(Moment).filter_by(session_id=s.id).order_by(Moment.rank).all() if s else []
    await update.message.reply_text("\n".join(f"#{m.rank} {m.start}-{m.end} {m.score}: {m.description}" for m in ms) or "No AI moments.")
async def setclips(update,context):
    if not context.args or not context.args[0].isdigit(): return await update.message.reply_text("Usage: /setclips number")
    n=max(1,min(20,int(context.args[0])))
    with SessionLocal() as db:
        s=db.get(Setting,"default_clips") or Setting(key="default_clips",value=str(n))
        s.value=str(n); db.add(s); db.commit()
    await update.message.reply_text(f"Default clips set to {n}.")
async def settings_cmd(update,context):
    with SessionLocal() as db: s=db.get(Setting,"default_clips")
    await update.message.reply_text(f"Default clips: {s.value if s else settings.default_clips}\nPoll interval: {settings.poll_seconds}s\nMax clip length: {settings.max_clip_seconds}s")
