from abc import ABC, abstractmethod
from pathlib import Path
from typing import Callable

class TikTokLiveCaptureAdapter(ABC):
    """Authorized capture interface.

    Implement this adapter with a TikTok LIVE capture mechanism you are
    authorized to use. This project intentionally does not bypass login,
    DRM, access controls, or other platform protections.
    """
    @abstractmethod
    async def record(self, username: str, output_path: Path, stop_event) -> None:
        raise NotImplementedError

class LocalFileCaptureAdapter(TikTokLiveCaptureAdapter):
    """Test adapter: copies a local MP4 to the requested output path."""
    def __init__(self, source: str): self.source = Path(source)
    async def record(self, username, output_path, stop_event):
        import shutil, asyncio
        if not self.source.exists():
            raise FileNotFoundError(self.source)
        shutil.copy2(self.source, output_path)
        await asyncio.sleep(0)
